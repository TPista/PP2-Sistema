<div class="col-2">
    <?php if(auth()->guard()->check()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opt_for_course', $course)): ?>
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subscribe', \App\Course::class)): ?>
                <a class="btn btn-subscribe btn-bottom btn-block" href="<?php echo e(route('subscriptions.plans')); ?>">
                    <i class="fa fa-bolt"></i> <?php echo e(__("Subscribirme")); ?>

                </a>
             <?php else: ?>
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inscribe', $course)): ?>
                    <a class="btn btn-subscribe btn-bottom btn-block" href="<?php echo e(route('courses.inscribe', ['slug' => $course->slug])); ?>">
                        <i class="fa fa-bolt"></i> <?php echo e(__("Inscribirme")); ?>

                    </a>
                 <?php else: ?>
                    <a class="btn btn-subscribe btn-bottom btn-block" href="#">
                        <i class="fa fa-bolt"></i> <?php echo e(__("Inscrito")); ?>

                    </a>
                 <?php endif; ?>
             <?php endif; ?>
        <?php else: ?>
            <a class="btn btn-subscribe btn-bottom btn-block" href="#">
                <i class="fa fa-user"></i> <?php echo e(__("Soy autor")); ?>

            </a>
        <?php endif; ?>
    <?php else: ?>
        <a class="btn btn-subscribe btn-bottom btn-block" href="<?php echo e(route('login')); ?>">
            <i class="fa fa-user"></i> <?php echo e(__("Acceder")); ?>

        </a>
    <?php endif; ?>
</div>