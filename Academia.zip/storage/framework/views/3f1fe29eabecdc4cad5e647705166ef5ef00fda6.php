<li><a class="nav-link" href="<?php echo e(route('admin.courses')); ?>"><?php echo e(__("Administrar cursos")); ?></a></li>
<li><a class="nav-link" href="#"><?php echo e(__("Administrar estudiantes")); ?></a></li>
<li><a class="nav-link" href="#"><?php echo e(__("Administrar profesores")); ?></a></li>
<?php echo $__env->make('partials.navigations.logged', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>