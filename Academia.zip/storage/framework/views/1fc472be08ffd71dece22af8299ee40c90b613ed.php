<?php $__env->startSection('jumbotron'); ?>
    <?php echo $__env->make('partials.jumbotron', ['title' => 'Manejar mis suscripciones', 'icon' => 'list-ol'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pl-5 pr-5">
        <div class="row justify-content-around">
            <table class="table table-hover table-dark">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Plan</th>
                        <th scope="col">ID Suscripción</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Alta</th>
                        <th scope="col">Finaliza en</th>
                        <th scope="col">Cancelar / Reanudar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <td><?php echo e($subscription->id); ?></td>
                        <td><?php echo e($subscription->name); ?></td>
                        <td><?php echo e($subscription->stripe_plan); ?></td>
                        <td><?php echo e($subscription->stripe_id); ?></td>
                        <td><?php echo e($subscription->quantity); ?></td>
                        <td><?php echo e($subscription->created_at->format('d/m/Y')); ?></td>
                        <td><?php echo e($subscription->ends_at ? $subscription->ends_at->format('d/m/Y') : __("Suscripción activa")); ?></td>
                        <td>
                            <?php if($subscription->ends_at): ?>
                                <form action="<?php echo e(route('subscriptions.resume')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="plan" value="<?php echo e($subscription->name); ?>" />
                                    <button class="btn btn-success">
                                        <?php echo e(__("Reanudar")); ?>

                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('subscriptions.cancel')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="plan" value="<?php echo e($subscription->name); ?>" />
                                    <button class="btn btn-danger">
                                        <?php echo e(__("Cancelar")); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8"><?php echo e(__("No hay ninguna suscripción disponible")); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>