<div class="col-12 pt-0 mt-4">
    <h2 class="text-muted">
        <?php echo e(__("Cursos similares")); ?>

    </h2>
    <hr />
</div>
<div class="container-fluid">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 listing-block">
                <div class="media">
                    <div class="fav-box">
                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                    </div>
                    <a href="<?php echo e(route('courses.detail', $relatedCourse->slug)); ?>">
                        <img
                            class="d-flex align-self-start"
                            src="/images/courses/<?php echo e($relatedCourse->picture); ?>"
                            alt="<?php echo e($relatedCourse->name); ?>"
                        />
                    </a>
                    <div class="media-body pl-3">
                        <div class="price">
                            <small><?php echo e($relatedCourse->name); ?></small>
                        </div>
                        <div class="stats">
                            <?php echo $__env->make('partials.courses.rating', ['rating' => $relatedCourse->custom_rating], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-dark">
                <?php echo e(__("No existe ningún curso relacionado")); ?>

            </div>
        <?php endif; ?>
    </div>
</div>