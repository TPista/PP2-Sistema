<div class="card card-01">
    <img
        class="card-img-top"
        src="<?php echo e($course->pathAttachment()); ?>"
        alt="<?php echo e($course->name); ?>"
    />
    <div class="card-body">
        <span class="badge-box"><i class="fa fa-check"></i></span>
        <h4 class="card-title"><?php echo e($course->name); ?></h4>
        <hr />
        <div class="row justify-content-center">
            <?php echo $__env->make('partials.courses.rating', ['rating' => $course->custom_rating], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <hr />
        <span class="badge badge-danger badge-cat"><?php echo e($course->category->name); ?></span>
        <p class="card-text">
            <?php echo e(str_limit($course->description, 100)); ?>

        </p>
        <a
            href="<?php echo e(route('courses.detail', $course->slug)); ?>"
            class="btn btn-course btn-block"
        >
            <?php echo e(__("Más información")); ?>

        </a>
    </div>
</div>