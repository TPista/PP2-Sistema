<a
    href="#"
    data-target="#appModal"
    title="<?php echo e(__("Enviar mensaje")); ?>"
    data-id="<?php echo e($user['id']); ?>"
    class="btn btn-primary btnEmail"
>
    <i class="fa fa-envelope-square"></i>
</a>