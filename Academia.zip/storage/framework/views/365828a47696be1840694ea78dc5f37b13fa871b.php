<?php $__env->startSection('jumbotron'); ?>
    <?php echo $__env->make('partials.jumbotron', ['title' => 'Administrar Profesores', 'icon' => 'unlock-alt'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pl-5 pr-5">
        <courses-list
            :labels="<?php echo e(json_encode([
                'name' => __("Nombre"),
                'status' => __("Estado"),
                'activate_deactivate' => __("Activar / Desactivar"),
                'approve' => __("Aprobar"),
                'reject' => __("Rechazar")
            ])); ?>"
            route="<?php echo e(route('admin.teachers_json')); ?>"
        >
        </teachers-list>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>