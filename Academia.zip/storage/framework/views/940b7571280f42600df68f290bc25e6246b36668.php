<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pricing.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('jumbotron'); ?>
    <?php echo $__env->make('partials.jumbotron', [
        'title' => __("Subscríbete ahora a uno de nuestros planes"),
        'icon' => 'globe'
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="pricing-table pricing-three-column row">
            <div class="plan col-sm-4 col-lg-4">
                <div class="plan-name-bronze">
                    <h2><?php echo e(__("MENSUAL")); ?></h2>
                    <span><?php echo e(__(":price / Mes", ['price' => '$ 9,99 ARS'])); ?></span>
                </div>
                <ul>
                    <li class="plan-feature"><?php echo e(__("Acceso a todos los cursos")); ?></li>
                    <li class="plan-feature"><?php echo e(__("Acceso a todos los archivos")); ?></li>
                    <li class="plan-feature">
                        <?php echo $__env->make('partials.stripe.form', [
                            "product" => [
                                "name" => __("Suscripción"),
                                "description" => __("Mensual"),
                                "type" => "monthly",
                                "amount" => 999,99
                            ]
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </li>
                </ul>
            </div>

            <div class="plan col-sm-4 col-lg-4">
                <div class="plan-name-silver">
                    <h2><?php echo e(__("Trimestral")); ?></h2>
                    <span><?php echo e(__(":price / 3 meses", ['price' => '$ 19,99 ARS'])); ?></span>
                </div>
                <ul>
                    <li class="plan-feature"><?php echo e(__("Acceso a todos los cursos")); ?></li>
                    <li class="plan-feature"><?php echo e(__("Acceso a todos los archivos")); ?></li>
                    <li class="plan-feature">
                        <?php echo $__env->make('partials.stripe.form',
                            ["product" => [
                                'name' => 'Suscripción',
                                'description' => 'Trimestral',
                                'type' => 'quarterly',
                                'amount' => 1999.99
                            ]]
                        , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </li>
                </ul>
            </div>

            <div class="plan col-sm-4 col-lg-4">
                <div class="plan-name-gold">
                    <h2><?php echo e(__("ANUAL")); ?></h2>
                    <span><?php echo e(__(":price / 12 meses", ['price' => ' $ 89,99 ARS'])); ?></span>
                </div>
                <ul>
                    <li class="plan-feature"><?php echo e(__("Acceso a todos los cursos")); ?></li>
                    <li class="plan-feature"><?php echo e(__("Acceso a todos los archivos")); ?></li>
                    <li class="plan-feature">
                        <?php echo $__env->make('partials.stripe.form',
                            ["product" => [
                                'name' => 'Suscripción',
                                'description' => 'Anual',
                                'type' => 'yearly',
                                'amount' => 8999.99
                            ]]
                        , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>