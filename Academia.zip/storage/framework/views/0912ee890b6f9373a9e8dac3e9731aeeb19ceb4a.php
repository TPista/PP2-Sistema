<?php $__env->startComponent('mail::message'); ?>

# <?php echo e(__("Curso Rechazado!")); ?>


<?php echo e(__("Tu curso :course no ha sido aprobado en la plataforma", ['course' => $course->name])); ?>

<img class="img-responsive" src="<?php echo e(url('storage/courses/' . $course->picture)); ?>" alt="<?php echo e($course->name); ?>">

<?php $__env->startComponent('mail::button', ['url' => url('/')]); ?>
    <?php echo e(__("Ir a la plataforma")); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo e(__("Gracias")); ?>,<br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?>