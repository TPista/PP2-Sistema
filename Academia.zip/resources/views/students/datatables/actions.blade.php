<a
    href="#"
    data-target="#appModal"
    title="{{ __("Enviar mensaje") }}"
    data-id="{{$user['id']}}"
    class="btn btn-primary btnEmail"
>
    <i class="fa fa-envelope-square"></i>
</a>